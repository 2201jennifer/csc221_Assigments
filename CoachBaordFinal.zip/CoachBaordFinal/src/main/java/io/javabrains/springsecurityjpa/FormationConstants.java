
package io.javabrains.springsecurityjpa;

public class FormationConstants {
    public static final String FORMATION_4_3_3 = "4-3-3";
    public static final String FORMATION_4_2_3_1 = "4-2-3-1";
    public static final String FORMATION_4_4_2 = "4-4-2";

    // We can add more formations later when we expand project
}
